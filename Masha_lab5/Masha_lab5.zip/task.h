#ifndef TASK_H
#define TASK_H

struct point
{
   int x0;
   int y0;
};

void save();
void chaikin();
void bez();
void createpoint(int,int);
void coordinats(int,int);

#endif